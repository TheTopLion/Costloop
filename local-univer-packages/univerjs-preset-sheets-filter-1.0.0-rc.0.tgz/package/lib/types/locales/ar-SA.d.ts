declare const _default: {
    'sheets-filter': {
        command: {
            'not-valid-filter-range': string;
        };
        msg: {
            'filter-header-forbidden': string;
        };
    };
} & {
    'sheets-filter-ui': {
        toolbar: {
            'smart-toggle-filter-tooltip': string;
            'clear-filter-criteria': string;
            're-calc-filter-conditions': string;
        };
        shortcut: {
            'smart-toggle-filter': string;
        };
        permission: {
            filterErr: string;
        };
        panel: {
            'clear-filter': string;
            cancel: string;
            confirm: string;
            mobile: {
                resize: string;
                back: string;
                column: string;
                'previous-column': string;
                'next-column': string;
            };
            'by-values': string;
            'by-colors': string;
            'filter-by-cell-fill-color': string;
            'filter-by-cell-text-color': string;
            'filter-by-color-none': string;
            'by-conditions': string;
            'filter-only': string;
            'search-placeholder': string;
            'select-all': string;
            'input-values-placeholder': string;
            and: string;
            or: string;
            empty: string;
            '?': string;
            '*': string;
        };
        conditions: {
            none: string;
            empty: string;
            'not-empty': string;
            'text-contains': string;
            'does-not-contain': string;
            'starts-with': string;
            'ends-with': string;
            equals: string;
            'greater-than': string;
            'greater-than-or-equal': string;
            'less-than': string;
            'less-than-or-equal': string;
            equal: string;
            'not-equal': string;
            between: string;
            'not-between': string;
            custom: string;
        };
        date: {
            1: string;
            2: string;
            3: string;
            4: string;
            5: string;
            6: string;
            7: string;
            8: string;
            9: string;
            10: string;
            11: string;
            12: string;
        };
        sync: {
            title: string;
            statusTips: {
                on: string;
                off: string;
            };
            switchTips: {
                on: string;
                off: string;
            };
        };
    };
};
export default _default;
